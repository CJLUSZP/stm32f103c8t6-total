#include "delay.h"
#include "sys.h"
#include "oled.h"
#include "bmp.h"

int main(void)
{
	
	u8 t;
	int NUM = 0;
	delay_init();
	OLED_Init();
	OLED_ColorTurn(0);//0������ʾ��1 ��ɫ��ʾ
  OLED_DisplayTurn(0);//0������ʾ 1 ��Ļ��ת��ʾ
//	OLED_DrawPoint(0,0);
//	OLED_DrawLine(20,0,50,60);
//	OLED_DrawCircle(64,32,20);
	OLED_Refresh();
	t=' ';
	
	while(1)
	{
		OLED_ShowString(8,0,"SPI-OLED",16);
		OLED_ShowString(20,16,"2023/10/24",16);
		OLED_ShowNum(0,48,NUM,3,16);
		delay_ms(1000);
		NUM++;
		OLED_Refresh();
	}
}

