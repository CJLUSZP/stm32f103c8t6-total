#ifndef __TIME_H
#define __TIME_H	
#include "string.h"
#include "sys.h"
#include "usart.h"
#include "ds18b20.h"


extern float temperature;
void TIM2_Getsample_Int(u16 arr,u16 psc);

#endif
