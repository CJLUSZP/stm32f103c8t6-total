#include "led.h"
#include "delay.h"
#include "sys.h"
#include "usart.h"
#include "key.h"
#include "time.h"
#include "oled.h"
#include "ds18b20.h"
#include "dht11.h"
#include "bh1750.h"

 int main(void)
 {	 
	u8 string[10] = {0};
	extern char s1[4];
	extern char s2[2] ;
	extern char s3[5];
	extern u8 dat[5];	  
	extern int Light;
	
	float temperature;

	delay_init();	    	 //��ʱ������ʼ��	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);// �����ж����ȼ�����2
	uart_init(9600);	 //���ڳ�ʼ��Ϊ9600
	LED_Init();		  	 //��ʼ����LED���ӵ�Ӳ���ӿ� 
	KEY_Init();
	TIM2_Getsample_Int(9999,719);		//400ms����ʱ�ж�
//(arr+1)*(psc+1)/72000000 =40000*720/72000 ms = 400ms 
	 
	OLED_Init();
	OLED_Refresh();
	OLED_Clear();           //????
	delay_ms(1000);
	
	DS18B20_Init();
	BH1750_Init(); 
	 
	while(1)
	{
		OLED_ShowString(40,0,"BH1750",16);
		
		sprintf(s1,"temp :%2d.%1d",dat[2],dat[3]);
		OLED_ShowString(0,16,s1,16);
		
		sprintf(s2,"wetness: %2d",dat[0]);
		OLED_ShowString(0,32,s2,16);
		
		sprintf(s3,"lightness: %2d",Light);
		OLED_ShowString(0,48,s3,16);

		
		OLED_Refresh();
	}	 
}


