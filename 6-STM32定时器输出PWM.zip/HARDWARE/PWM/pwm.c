#include "stm32f10x.h"
#include "pwm.h"
//////////////////////////////////////////////////////////////////////////////////	 


//PWM�����ʼ��
//arr���Զ���װֵ
//psc��ʱ��Ԥ��Ƶ��


void TIM3_PWM_Init_Servo(u16 Arr,u16 Psc)      
{

	GPIO_InitTypeDef GPIO_InitStruct;         
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStruct;
	TIM_OCInitTypeDef TIM_OCInitStruct;   //?????
	
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_GPIOB|RCC_APB2Periph_AFIO,ENABLE);        //????  
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);
	
	GPIO_InitStruct.GPIO_Mode=GPIO_Mode_AF_PP;      //???GPIOB
	GPIO_InitStruct.GPIO_Pin=GPIO_Pin_0|GPIO_Pin_1;
	GPIO_InitStruct.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&GPIO_InitStruct);
	
	GPIO_InitStruct.GPIO_Mode=GPIO_Mode_AF_PP;      //???GPIOA
	GPIO_InitStruct.GPIO_Pin=GPIO_Pin_6|GPIO_Pin_7;
	GPIO_InitStruct.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStruct);
 
	TIM_TimeBaseStructInit(&TIM_TimeBaseInitStruct);     //??????
	TIM_TimeBaseInitStruct.TIM_ClockDivision=TIM_CKD_DIV1;       
	TIM_TimeBaseInitStruct.TIM_CounterMode=TIM_CounterMode_Up;     
	TIM_TimeBaseInitStruct.TIM_Period=Arr;         
	TIM_TimeBaseInitStruct.TIM_Prescaler=Psc;      
	TIM_TimeBaseInitStruct.TIM_ClockDivision=0;	
	TIM_TimeBaseInit(TIM3,&TIM_TimeBaseInitStruct);
 
	TIM_OCInitStruct.TIM_OCMode=TIM_OCMode_PWM1;          //???????
	TIM_OCInitStruct.TIM_OCPolarity=TIM_OCPolarity_High;
	TIM_OCInitStruct.TIM_OutputState=TIM_OutputState_Enable;
	TIM_OCInitStruct.TIM_Pulse=0;
	
	TIM_OC1Init(TIM3,&TIM_OCInitStruct );          //???4??1:A6 2:A7 3:B0 4:B1
	TIM_OC2Init(TIM3,&TIM_OCInitStruct );
	TIM_OC3Init(TIM3,&TIM_OCInitStruct );          
	TIM_OC4Init(TIM3,&TIM_OCInitStruct );
	
	TIM_OC1PreloadConfig(TIM3,TIM_OCPreload_Enable);
	TIM_OC2PreloadConfig(TIM3,TIM_OCPreload_Enable);
	TIM_OC3PreloadConfig(TIM3,TIM_OCPreload_Enable);      //OC1-OC4???????
	TIM_OC4PreloadConfig(TIM3,TIM_OCPreload_Enable);		
	
	TIM_ARRPreloadConfig(TIM3,ENABLE);      //TIM3?APR?????????
	
	TIM_Cmd(TIM3,ENABLE);    //????
	
	
}




void TIM3_PWM_Config(u16 pwm1,u16 pwm2,u16 pwm3,u16 pwm4)
{
	TIM_SetCompare1(TIM3,pwm1);
	TIM_SetCompare2(TIM3,pwm2);
	TIM_SetCompare3(TIM3,pwm3);
	TIM_SetCompare4(TIM3,pwm4);
}



//TIM4 PWM????? 
//PWM?????
//arr:?????
//psc:??????
void TIM4_PWM_Init(uint16_t arr,uint16_t psc)
{  
	GPIO_InitTypeDef GPIO_InitStructure;
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
	TIM_OCInitTypeDef  TIM_OCInitStructure;
	

	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);	//?????3??
 	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB  , ENABLE);  //??GPIO???AFIO????????
	//RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);        //IO ??
    //GPIO_PinRemapConfig(GPIO_Remap_TIM4, ENABLE);     //TIM4??????,???,???IO??
    
    //???????,TIM4?????CH1,CH2,CH3,CH4????  PB6     PB7     PB8     PB9
    //???????,TIM4?????CH1,CH2,CH3,CH4????  PD12    PD13    PD14    PD15 
    
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8|GPIO_Pin_9; 
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;  //??????
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);//???GPIO
 
   //???TIM4
	TIM_TimeBaseStructure.TIM_Period = arr; //???????????????????????????
	TIM_TimeBaseStructure.TIM_Prescaler =psc; //??????TIMx??????????? 
	TIM_TimeBaseStructure.TIM_ClockDivision = 0; //??????:TDTS = Tck_tim
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;  //TIM??????
	TIM_TimeBaseInit(TIM4, &TIM_TimeBaseStructure); //??TIM_TimeBaseInitStruct?????????TIMx???????
	
    TIM_OCInitStructure.TIM_Pulse = 0; 
    
	//???TIM3 Channel2 PWM??	 
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1; //???????:TIM????????2
 	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable; //??????
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High; //????:TIM???????
	
  TIM_OC3Init(TIM4, &TIM_OCInitStructure);
	TIM_OC3PreloadConfig(TIM4, TIM_OCPreload_Enable);
    
  TIM_OC4Init(TIM4, &TIM_OCInitStructure);    
  TIM_OC4PreloadConfig(TIM4, TIM_OCPreload_Enable);
    
	TIM_Cmd(TIM4, ENABLE);  


		
}

void TIM8_PWM_Init_Servo(u16 Arr,u16 Psc)      
{
	/********************
	   PB0?PB1??PWM???
	**********************/
	GPIO_InitTypeDef GPIO_InitStruct;         
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStruct;
	TIM_OCInitTypeDef TIM_OCInitStruct;   //?????
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC|RCC_APB2Periph_AFIO,ENABLE);        //????  
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM8, ENABLE);	//?????3??

	GPIO_InitStruct.GPIO_Mode=GPIO_Mode_AF_PP;      //???GPIOB
	GPIO_InitStruct.GPIO_Pin=GPIO_Pin_6|GPIO_Pin_7;
	GPIO_InitStruct.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOC,&GPIO_InitStruct);
 
	TIM_TimeBaseStructInit(&TIM_TimeBaseInitStruct);     //??????
	TIM_TimeBaseInitStruct.TIM_ClockDivision=TIM_CKD_DIV1;       
	TIM_TimeBaseInitStruct.TIM_CounterMode=TIM_CounterMode_Up;     
	TIM_TimeBaseInitStruct.TIM_Period=Arr;         
	TIM_TimeBaseInitStruct.TIM_Prescaler=Psc;      
	TIM_TimeBaseInitStruct.TIM_ClockDivision=0;	
	TIM_TimeBaseInit(TIM8,&TIM_TimeBaseInitStruct);
	
 
	TIM_OCInitStruct.TIM_OCMode=TIM_OCMode_PWM1;          //???????
	TIM_OCInitStruct.TIM_OCPolarity=TIM_OCPolarity_High;
	TIM_OCInitStruct.TIM_OutputState=TIM_OutputState_Enable;
	TIM_OCInitStruct.TIM_Pulse=0;
	
	TIM_OC1Init(TIM8,&TIM_OCInitStruct );          //???4??1:A6 2:A7 3:B0 4:B1
	TIM_OC2Init(TIM8,&TIM_OCInitStruct );

	TIM_OC1PreloadConfig(TIM8,TIM_OCPreload_Enable);
	TIM_OC2PreloadConfig(TIM8,TIM_OCPreload_Enable);

	TIM_ARRPreloadConfig(TIM8,ENABLE);      //TIM3?APR?????????
	
	TIM_Cmd(TIM8,ENABLE);    //????
	TIM_CtrlPWMOutputs(TIM8, ENABLE); 
}

void TIM48_PWM_Config(u16 pwm1,u16 pwm2,u16 pwm3,u16 pwm4)
{

	TIM_SetCompare1(TIM8,pwm1);
	TIM_SetCompare2(TIM8,pwm2);
  TIM_SetCompare3(TIM4,pwm3);
  TIM_SetCompare4(TIM4,pwm4);
}
