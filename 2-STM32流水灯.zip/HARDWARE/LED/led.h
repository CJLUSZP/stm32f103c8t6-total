#ifndef __LED_H
#define __LED_H	 
#include "sys.h"

#define LED0 PCout(13)	
#define LED1 PAout(0)	
#define LED2 PAout(1)	
#define LED3 PAout(2)	
#define LED4 PAout(3)	
#define LED5 PAout(4)	
#define LED6 PAout(5)
#define LED7 PAout(6)
#define LED8 PAout(7)	

void LED_Init(void);//��ʼ��

		 				    
#endif
