#include "led.h"
#include "delay.h"
#include "sys.h"
#include "usart.h"
#include "key.h"
#include "time.h"
#include "oled.h"

 int main(void)
 {	 
	u8 key_value =0 ;
	u8 string[10] = {0};
	u8 num = 0;
	
	delay_init();	    	 //��ʱ������ʼ��	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);// �����ж����ȼ�����2
	uart_init(9600);	 //���ڳ�ʼ��Ϊ9600
	LED_Init();		  	 //��ʼ����LED���ӵ�Ӳ���ӿ� 
	KEY_Init();
	TIM2_Getsample_Int(39999,719);		//400ms����ʱ�ж�
//(arr+1)*(psc+1)/72000000 =40000*720/72000 ms = 400ms 
	 
	OLED_Init();
	OLED_Refresh();
	OLED_Clear();           //????
	delay_ms(1000);
	 
	while(1)
	{
		OLED_ShowString(40,0,"OLED",16);
		OLED_ShowString(0,16,"key_press",16);
		OLED_Refresh();
		
		key_value = KEY_Scan(0);

		switch(key_value)
		{
			case 1 :printf("\r\nKEY0 pressed");LED0 = 0;num = key_value;break;
			case 2 :printf("\r\nKEY1 pressed");LED0 = 1;num = key_value;break;
			case 3 :printf("\r\nKEY2 pressed");LED0 = 0;num = key_value;break;
			case 4 :printf("\r\nKEY3 pressed");LED0 = 1;num = key_value;break;
			default:break;
		}
		
		sprintf((char *)string,"num:%d\r\n",num);//0300
		OLED_ShowString(0,32,string,16);
		OLED_Refresh();
	}	 
}


